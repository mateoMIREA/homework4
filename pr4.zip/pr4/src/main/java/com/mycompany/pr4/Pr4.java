/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.pr4;

import java.util.Scanner;

/**
 *
 * @author М_З_А
 */
public class Pr4 {

    public static void main(String[] args) {
        System.out.println("РИБО-01-21, Практика №4, Вариант №4, Новиков М.С.");
        PassportList passportList = new PassportList();
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("Введите номер пропуска:");
            int number = scanner.nextInt();
            System.out.println("Введите имя:");
            String name = scanner.next();
            System.out.println("Введите должность:");
            String position = scanner.next();
            System.out.println("Введите 1 для выдачи доступа или 0 для отказа в доступе:");
            boolean access = scanner.nextInt() == 1;
            passportList.addPassport(number, name, position, access);
        }
    }
    }
