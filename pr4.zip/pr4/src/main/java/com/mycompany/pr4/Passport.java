/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pr4;

/**
 *
 * @author М_З_А
 */
public class Passport {
    private int number;
    private String name;
    private String position;
    private boolean access;

    Passport(int number, String name, String position, boolean access) {
        this.number = number;
        this.name = name;
        this.position = position;
        this.access = access;
    }

    public int getNumber() {
        return number;
    }

    public String getName() {
        return name;
    }

    public boolean getAccess() {
        return access;
    }

    @Override
    public String toString() {
        return number + ", " + name + ", " + position + ", " + (access ? "Есть доступ" : "Нет доступа");
    }
}
